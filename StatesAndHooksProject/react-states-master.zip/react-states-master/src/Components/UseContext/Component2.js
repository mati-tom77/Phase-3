import React from "react";
import Component3 from "./Component3";
import UsingUseContext from "./UsingUseContext";

function Component2() {
  return (
    <div>
      <Component3 />
      <UsingUseContext />
    </div>
  );
}

export default Component2;
