import React from "react";
import Component2 from "./Component2";

function Component1() {
  return (
    <div>
      <Component2 />
    </div>
  );
}

export default Component1;
